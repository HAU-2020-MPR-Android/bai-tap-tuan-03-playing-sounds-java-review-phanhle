package com.phanhle.phraseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    MediaPlayer mp;
    public void onCLickPhrase(View view){
        //get entry name of clicked view
        String buttonIDName = view.getResources().getResourceEntryName(view.getId());
        Log.i("i", buttonIDName);

        //get sound resourse id
        int soundID = getResources().getIdentifier(buttonIDName, "raw", getPackageName());
        Log.i("i", ""+soundID);

        //create MediaPlayer with sound id
        mp = MediaPlayer.create(this, soundID);
        mp.start();

    }
}
