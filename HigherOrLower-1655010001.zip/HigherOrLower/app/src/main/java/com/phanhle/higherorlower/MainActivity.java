package com.phanhle.higherorlower;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // init random number
        setRandomNumber();

        // init user right guess counter (point)
        setRightGuessCounter(0);
    }

    private int rightGuessCounter;
    private int randomNumber;

    private void setRandomNumber(){
        // random number in rannge [1,20]
        randomNumber = (int)((Math.random() * 21) + 1);
        Log.i("random number", ""+randomNumber);
    }

    public void setRightGuessCounter(int n){
        rightGuessCounter = n;
        Log.i("counter", "counter update to "+ n);
        // update to View
        TextView counterView = findViewById(R.id.counter);
        counterView.setText(""+getRightGuessCounter());
        counterView.animate().alphaBy(0.5f).alphaBy(1).setDuration(3*1000);
    }

    public int getRightGuessCounter() { return rightGuessCounter;}


    public void onGuessClick(View view){
        // get EditText view
        EditText userNumView = findViewById(R.id.userNum);
        String msg;

        if(userNumView.getText().length() > 0){
            // get number from view
            int userNum = Integer.parseInt(userNumView.getText().toString());

            // check user number with app random number
            if(userNum > randomNumber){
                msg = "Lower!";
            } else if(userNum < randomNumber){
                msg = "Higher!";
            } else {
                msg = "Bingo! Let's try one more time!";
                setRightGuessCounter(getRightGuessCounter() + 1);
            }

            //show message to user
            Toast.makeText(this, msg, 5*1000).show();

        }
    }
}
