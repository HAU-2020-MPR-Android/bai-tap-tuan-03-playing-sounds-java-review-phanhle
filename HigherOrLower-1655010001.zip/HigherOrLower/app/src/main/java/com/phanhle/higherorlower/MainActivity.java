package com.phanhle.higherorlower;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userNumView = findViewById(R.id.userNum);
        userNumView.setFilters(new InputFilter[]{ new InputFilterMinMax("1", "20")});

        // init random number
        setRandomNumber();

        //TODO: init wrongGuessCounter
        setWrongGuessCounter(0);

        /*
        // init user right guess counter (point)
        setRightGuessCounter(0);

         */
    }

    /*
    private int rightGuessCounter;

     */

    //TODO: changing counter from right guess to wrong guess
    // and reset it to 0
    // when user guess right
    private int wrongGuessCounter;

    private int randomNumber;

    private EditText userNumView;

    //TODO: define setWrongCounter function
    private void setWrongGuessCounter(int n){
        wrongGuessCounter = n;
        //update to UI
        ((TextView)findViewById(R.id.counter)).setText(String.valueOf(wrongGuessCounter));
    }


    private void setRandomNumber(){
        // random number in range [1,20]
        randomNumber = (int)((Math.random() * 21) + 1);
        Log.i("random number", ""+randomNumber);
    }

//    public void setRightGuessCounter(int n){
//        rightGuessCounter = n;
//        Log.i("counter", "counter update to "+ n);
//        // update to View
//        TextView counterView = findViewById(R.id.counter);
//        counterView.setText(""+getRightGuessCounter());
//        counterView.animate().alphaBy(0.5f).alphaBy(1).setDuration(3*1000);
//    }

//    public int getRightGuessCounter() { return rightGuessCounter;}


    public void onGuessClick(View view){
        String msg;

        if(userNumView.getText().length() > 0){
            // get number from view
            int userNum = Integer.parseInt(userNumView.getText().toString());

            // check user number with app random number
            //TODO: increment wrongCounter when user guess wrong
            // increment expressions is repeated
            // create new var to store 2 states: wrong, !wrong(right)
            boolean guessWrong = true;
            if(userNum > randomNumber){
                msg = "Lower!";
            } else if(userNum < randomNumber){
                msg = "Higher!";
            } else {
                msg = "Bingo! Let's try one more time!";
                //TODO: remember random when user guess right
                setRandomNumber();
                guessWrong = false;

                /*
                setRightGuessCounter(getRightGuessCounter() + 1);
                 */
            }
            //TODO: increment counter in wrong state
            // reset counter to 0 in !wrong state
            if(guessWrong)
                setWrongGuessCounter(wrongGuessCounter + 1);
            else
                setWrongGuessCounter(0);


            //show message to user
            Toast.makeText(this, msg, 5*1000).show();

        }
    }
}
