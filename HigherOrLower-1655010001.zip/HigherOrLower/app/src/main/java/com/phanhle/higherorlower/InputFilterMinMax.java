package com.phanhle.higherorlower;

import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;

public class InputFilterMinMax implements InputFilter {

    private int min, max;

    public InputFilterMinMax(int min, int max){
        this.min = min;
        this.max = max;
    }

    public InputFilterMinMax(String minStr, String maxStr){
        this.min = Integer.parseInt(minStr);
        this.max = Integer.parseInt(maxStr);
    }

    @Override
    public CharSequence filter(
            CharSequence source, int start, int end,
            Spanned dest, int dstart, int dend) {
        //debug
        Log.i("Filter func: ", String.format("source: %s %d %d %d", source.toString(),source.length(),start,end));
        Log.i("Filter func: ", "dest: "+dest.toString()+ dstart+"->"+dend);

        // if user delete number then app is crashed
        // fact 1: source is in not null, it in "" string
        // fact 2: exception comes from Integer.parseInt() -> newVal="" -> Integer cannot parse("")

        String newVal = dest.toString().substring(0, dstart)
                        + dest.toString().substring(dend);
        newVal = newVal.substring(0, dstart)
                + source.toString()
                + newVal.substring(dstart);
        if(newVal.length() > 0){
            int input = Integer.parseInt(newVal);
            // case: when user want to enter a number lower than min,
            // if this case is not checked
            // result: then the input number(source) is never shown
            if(isLowerThanRange(min, max, input) || isInRange(min, max, input)){
                return null;
            }
        }


        return "";
    }

    private boolean isInRange(int min, int max, int input){
        return min < max
                ? (input >= min && input <= max)
                : (input >= max && input >= min);
    }

    private boolean isLowerThanRange(int min, int max, int input){
        return min < max
                ? (input < min)
                : (input < max);
    }
}
